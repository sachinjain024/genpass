window.PG = window.PG || {};
PG.CONSTANTS = {
  SETTINGS: {
    RANDOM_GENERATION_TYPE: 'random',
    CONSISTENT_GENERATION_TYPE: 'consistent',
    DEFAULT_PASSWORD_LENGTH: 12,
    DEFAULT_MASTER_STRING: '<M@sT3r/>',
    KEY_NAME_IN_STORAGE: 'settings'
  }
};
